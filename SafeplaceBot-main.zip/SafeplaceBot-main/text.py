# Первая фраза бота
greet = 'Привет, {name}!\n\nЯ Safeplace Bot, пройдешь опрос?'

# Кнопка для прохождения опроса
start_button = "📝 Начать опрос"

# Общие вопросы ко всем
first_question = '1. Ты артист или сонграйтер?'
firtst_answers_text = ["🎙 Артист", "✏️ Сонграйтер"]

second_question = '2. Выбери свой основной жанр'
second_question_answers_text = ["👑 Pop", "🎧 Hip-Hop", "🎸 Rock & Alternative", "👄 R&B", "🌻 Indie", "⚡️ Electronic Music", "🎙 Singer-Songwriter", "🍁 Folk"]

fourth_question = 'Есть ли у тебя музыкальный опыт работы онлайн?' #убрать
fourth_question_answers_text = ["Да", "Нет"]

fifth_question = 'Был ли у тебя музыкальный опыт командной работы?' #убрать
fifth_question_answers_text = ["Да", "Нет"]

seventh_question = 'Играешь ли ты на музыкальном инструменте?' #убрать
seventh_question_answers_text = ["Да", "Нет"]

eighth_question = '3. Выбери свой часовой пояс'
eighth_question_answers_text = ['MSK-1', 'MSK', 'MSK+1', 'MSK+2', 'MSK+3', 'MSK+4', 'MSK+5', 'MSK+6', 'MSK+7', 'MSK+8', 'MSK+9']

# Уникальные вопросы для артиста
third_question_artist = '2. Есть ли выпущенные песни на площадках, над которыми ты работал?' #убрать
third_question_answers_artist = ["Да", "Нет"]

sixth_question_artist = '3. Как долго ты поешь / читаешь?' #убрать
sixth_question_answers_text = ["Меньше месяца", "Несколько месяцев", "Около года", "Больше двух лет"]


# Уникальные вопросы для сонграйтера
third_question_songwriter = 'Есть ли выпущенные песни на площадках, в которых ты работал в качестве сонграйтера?'
third_question_answers_songwriter = ["Да", "Нет"]

extra_question_songwriter = 'Ты пишешь мелодии и/или текст?'
extra_question_answers_text = ["Мелодии", "Текст", "Мелодии и текст"]

sixth_question_songwriter =  'Как долго ты занимаешься музыкой?' # Тут в ответе кнопки такие же как в sixth_question_answers_text

# Конец опроса
end_phrase = '<strong>Сохранить результаты?</strong>'
end_buttons_text = ["🔒 Сохранить результаты", "↪️ Пройти заново"]

end_text = 'Результаты успешно сохранены!'

#РАБОТА С ГРУППАМИ
chat_list = "Список доступных чатов:"
chat_greeting = "Добро пожаловать в группу!"
chat_join_button_text = "📝 Вступить в чат"

# Посмотреть результаты анкеты для участников группы
info_button_text = "Получить информацию о группе"

# Кнопка для выдачи чатов 
continue_text = "Следующий чат"
go_survey_text = "Назад к опросу"
choose_chat = "Выбрать"
back_text = "Предыдущий чат"
next_member = "Следующая анкета"
back_to_chats = "Вернуться к выбору чатов"
empty_chat = "На данный момент все актуальные чаты переполнены.\n\nВы можете создать свой или вернуться к опросу."
buy_text = "Оплатить"
end_of_survey = "Выше вы можете ознакомиться с анкетами участников"
empty_chat2 = "Вы уверены, что хотите присоединиться к этому чату?"
end_chat_text = "На данный момент это все активные чаты. Вы можете выбрать один из них или дождаться, пока появятся новые."

survey_member_genre = "Основной жанр:"
survey_member_time = "Часовой пояс:"

# Функция для выдачи чатов
def send_chats(chat_message, info_group_list, key, private_name_list):
    print(key)
    print(info_group_list)
    if info_group_list[key][2] == "INACTIVE":
        status = "Набор участников"
    elif info_group_list[key][2] == "ACTIVE":
        status = "Набор участников"
    artist = info_group_list[key][0]
    songwriter = info_group_list[key][1]
        
    chat_name = chat_message[key]
    private_name = private_name_list[key]
    
    if private_name == "":
        result = f'''
        <b>{chat_name}</b>
        
<b>🎤Артист: {artist}/1</b>
<b>🎹Сонграйтер: {songwriter}/3</b>
        
        Статус группы: <i>{status}</i> '''
    else:
        result = f'''
        <strong>{private_name}</strong>
    
<i>{chat_name}</i>
        
<b>🎤Артист:  {artist}/1</b>
<b>🎹Сонграйтер:  {songwriter}/3\n</b>
        
Статус группы:  <i>{status}</i> '''
    
    return result
    
        
def send_choosen_chat(chat_message, info_group_list, key, private_name_list):
    if info_group_list[key][2] == "INACTIVE":
        status = "Пусто"
    elif info_group_list[key][2] == "ACTIVE":
        status = "Набор участников"
    artist = info_group_list[key][0]
    songwriter = info_group_list[key][1]
        
    chat_name = chat_message[key]
    private_name = private_name_list[key]
    if private_name == None:
        result = f'''
        <strong>{chat_name}</strong>
        
<i>Артист: {artist}</i>
<i>Сонграйтер: {songwriter}</i>
<i>Статус группы: {status}</i>'''
         
    else:
        result = f'''
        <strong> {private_name} </strong>
    
<strong>{chat_name}</strong>
        
<i>Артист: {artist}</i>
<i>Сонграйтер: {songwriter}</i>
<i>Статус группы: {status}</i>'''
    
    return result

# Служебные функции для парсинга ответов
def parse_answers_chats(dic, has_artist, name):
    if has_artist == "Я артист":
        result = f'''
<strong>Анкета {name}:\n</strong>
        <b>🎙 Артист\n</b>
        {survey_member_genre} 
        - <strong>{dic['client_genre']}</strong>
        
        {survey_member_time}
        - <strong>{dic['time_zone']}</strong>'''
        
        return result
    
    result = f'''
<strong>Анкета {name}:\n</strong>
        <b>✏️ Сонграйтер\n</b>
        {survey_member_genre} 
        - <strong>{dic['client_genre']}</strong>
        
        {survey_member_time}
        - <strong>{dic['time_zone']}</strong>'''
        
    return result
        

def parse_answers(dic):
    result = f'''
<strong>Ваша анкета:</strong>
    
<i>{first_question}</i> 
- <strong>{dic['client_role']}</strong>
    
<i>{second_question}</i> 
- <strong>{dic['client_genre']}</strong>
    
<i>{eighth_question}</i> 
- <strong>{dic['time_zone']}</strong>'''
    
    return result

# РАБОТА С ГРУППОй

def chat_text():
    result = f'''
    Ниже представлены все доступные команды:
    1) Сменить имя чата - /change_name
    2) Связь с администрацией - /admin'''
    
    return result
