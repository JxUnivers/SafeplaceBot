buy = """
Если вы уже приобрели товар, то нажмите на кнопку "Проверить оплату"
"""

wait_msg = """
Вы не оплатили товар или оплата еще в пути!
"""

successful_payment = """
Добро пожаловать к нам в команду! :)
"""

MESSAGES = {
    'successful_payment': successful_payment,
    'buy': buy,
    'wait_message': wait_msg,
}

buy_button = "Произвести оплату"