from yoomoney import Authorize

Authorize(
    client_id="D38B8CB29DD902177D6899001BB97F3168FC948A0A21C0B22E81945C5C751311",
    redirect_uri="https://t.me/SafePlaceTeamBot",
    scope=["account-info",
             "operation-history",
             "operation-details",
             "incoming-transfers",
             "payment-p2p",
             "payment-shop",
            ]
    
    )