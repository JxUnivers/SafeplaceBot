from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, KeyboardButton, ReplyKeyboardMarkup, ReplyKeyboardRemove 
from aiogram.utils.keyboard import InlineKeyboardBuilder
import text
import p2p_messages






menu_start_button = InlineKeyboardButton(text=text.start_button, callback_data='start_survey')

menu_start = InlineKeyboardBuilder()
menu_start.add(menu_start_button)

# Первый вопрос
first_answers = ['Я артист', 'Я сонграйтер']

first_question_buttons = [
    InlineKeyboardButton(text=text.firtst_answers_text[0], callback_data = 'Я артист'), 
    InlineKeyboardButton(text=text.firtst_answers_text[1], callback_data = 'Я сонграйтер')
]

first_question_menu = InlineKeyboardBuilder()

for i in first_question_buttons:
    first_question_menu.add(i).adjust(1)


second_question_buttons = [
    InlineKeyboardButton(text=text.second_question_answers_text[0], callback_data = 'Pop'), 
    InlineKeyboardButton(text=text.second_question_answers_text[1], callback_data = 'Hip-Hop'),
    InlineKeyboardButton(text=text.second_question_answers_text[2], callback_data = 'Rock & Alternative'), 
    InlineKeyboardButton(text=text.second_question_answers_text[3], callback_data = 'R&B'),
    InlineKeyboardButton(text=text.second_question_answers_text[4], callback_data = 'Indie'), 
    InlineKeyboardButton(text=text.second_question_answers_text[5], callback_data = 'Electronic Music'),
    InlineKeyboardButton(text=text.second_question_answers_text[6], callback_data = 'Singer-Songwriter'), 
    InlineKeyboardButton(text=text.second_question_answers_text[7], callback_data = 'Folk'),
]

second_question_menu = InlineKeyboardBuilder()

for i in second_question_buttons:
    second_question_menu.add(i).adjust(1)

genres = ["Pop", "Hip-Hop", "Rock & Alternative", "R&B", "Indie", "Electronic Music", "Singer-Songwriter", "Folk"]

# Вопросы для артиста

# Третий вопрос - 'Если ли выпущенные песни на площадках, над которыми ты работал?'
third_answers_artist = ['Есть (артист)', 'Нет (артист)']

third_question_buttons_artist = [
    InlineKeyboardButton(text=text.third_question_answers_artist[0], callback_data = 'Есть (артист)'), 
    InlineKeyboardButton(text=text.third_question_answers_artist[1], callback_data = 'Нет (артист)')
]

third_question_menu_artist = InlineKeyboardBuilder()

for i in third_question_buttons_artist:
    third_question_menu_artist.add(i)
    

#Четвёртый вопрос - 'Есть ли у тебя музыкальный опыт работы онлайн?'
fourth_answers = ["Да, работал онлайн", "Нет, не работал"]

fourth_question_buttons = [
    InlineKeyboardButton(text=text.fourth_question_answers_text[0], callback_data = "Да, работал онлайн"),
    InlineKeyboardButton(text=text.fourth_question_answers_text[1], callback_data = "Нет, не работал")
]

fourth_question_menu = InlineKeyboardBuilder()

for i in fourth_question_buttons:
    fourth_question_menu.add(i)

#Пятый вопрос - 'Был ли у тебя музыкальный опыт командной работы?'
fifth_answers = ["Да, работал в команде", "Нет, работал один"]

fifth_question_buttons = [
    InlineKeyboardButton(text=text.fifth_question_answers_text[0], callback_data = "Да, работал в команде"), 
    InlineKeyboardButton(text=text.fifth_question_answers_text[1], callback_data = "Нет, работал один")
]

fifth_question_menu = InlineKeyboardBuilder()

for i in fifth_question_buttons:
    fifth_question_menu.add(i)



#Шестой вопрос - 'Как долго ты поешь / читаешь?'
sixth_answers = ["Меньше месяца", "Несколько месяцев", "Около года", "Больше двух лет"]

sixth_question_buttons = [
    InlineKeyboardButton(text=text.sixth_question_answers_text[0], callback_data = "Меньше месяца"),
    InlineKeyboardButton(text=text.sixth_question_answers_text[1], callback_data = "Несколько месяцев"),
    InlineKeyboardButton(text=text.sixth_question_answers_text[2], callback_data = "Около года"),
    InlineKeyboardButton(text=text.sixth_question_answers_text[3], callback_data = "Больше двух лет")
]

sixth_question_menu = InlineKeyboardBuilder()

for i in sixth_question_buttons:
    sixth_question_menu.add(i).adjust(1)


#Седьмой вопрос - 'Играешь ли ты на музыкальном инструменте?'
seventh_answers = ["Да, играю", "Нет, не играю"]
seventh_question_buttons = [
    InlineKeyboardButton(text=text.seventh_question_answers_text[0], callback_data = "Да, играю"),
    InlineKeyboardButton(text=text.seventh_question_answers_text[1], callback_data = "Нет, не играю"),
]

seventh_question_menu = InlineKeyboardBuilder()

for i in seventh_question_buttons:
    seventh_question_menu.add(i)

#Восьмой вопрос - 'Твой часовой пояс?'
eighth_answers = ["MSK-1", "MSK", "MSK+1", "MSK+2", "MSK+3", "MSK+4", "MSK+5", "MSK+6", "MSK+7", "MSK+8", "MSK+9"]

eighth_question_buttons = [
    InlineKeyboardButton(text=text.eighth_question_answers_text[1], callback_data = 'MSK'), 
    InlineKeyboardButton(text=text.eighth_question_answers_text[0], callback_data = 'MSK-1'),
    InlineKeyboardButton(text=text.eighth_question_answers_text[2], callback_data = 'MSK+1'), 
    InlineKeyboardButton(text=text.eighth_question_answers_text[3], callback_data = 'MSK+2'),
    InlineKeyboardButton(text=text.eighth_question_answers_text[4], callback_data = 'MSK+3'), 
    InlineKeyboardButton(text=text.eighth_question_answers_text[5], callback_data = 'MSK+4'),
    InlineKeyboardButton(text=text.eighth_question_answers_text[6], callback_data = 'MSK+5'), 
    InlineKeyboardButton(text=text.eighth_question_answers_text[7], callback_data = 'MSK+6'),
    InlineKeyboardButton(text=text.eighth_question_answers_text[8], callback_data = 'MSK+7'),
    InlineKeyboardButton(text=text.eighth_question_answers_text[9], callback_data = 'MSK+8'), 
    InlineKeyboardButton(text=text.eighth_question_answers_text[10], callback_data = 'MSK+9'),
]

eighth_question_menu = InlineKeyboardBuilder()

for i in eighth_question_buttons:
    eighth_question_menu.add(i).adjust(2)
    
#Конец опроса
end_answers = ["Сохранить результаты", "repeat-survey"]

end_buttons = [
    InlineKeyboardButton(text = text.end_buttons_text[0], callback_data = "Сохранить результаты"),
    InlineKeyboardButton(text = text.end_buttons_text[1], callback_data = "repeat-survey")
]

end_menu = InlineKeyboardBuilder()

for i in end_buttons:
    end_menu.add(i).adjust(1)

# Вопросы для сонграйтера
third_answers_songwriter = ['Есть (сонграйтер)', 'Нет (сонграйтер)']

third_question_buttons_songwriter = [
    InlineKeyboardButton(text=text.third_question_answers_songwriter[0], callback_data = 'Есть (сонграйтер)'), 
    InlineKeyboardButton(text=text.third_question_answers_songwriter[1], callback_data = 'Нет (сонграйтер)')
]

third_question_menu_songwriter = InlineKeyboardBuilder()

for i in third_question_buttons_songwriter:
    third_question_menu_songwriter.add(i)
    
    
# Экстра вопрос - Ты пишешь мелодии и/или текст?

extra_answers_songwriter = ["Мелодии", "Текст", "Мелодии и текст"]

extra_question_buttons = [
    InlineKeyboardButton(text=text.extra_question_answers_text[0], callback_data = "Мелодии"),
    InlineKeyboardButton(text=text.extra_question_answers_text[1], callback_data = "Текст"),
    InlineKeyboardButton(text=text.extra_question_answers_text[2], callback_data = "Мелодии и текст")
]

extra_question_menu = InlineKeyboardBuilder()

for i in extra_question_buttons:
    extra_question_menu.add(i).adjust(1)
    
#КНОПКИ ЧАТОВ
chat_answers = ["back-survey"]

chat_buttons_start = [
    InlineKeyboardButton(text = text.continue_text, callback_data = "Следующий чат"),
    InlineKeyboardButton(text = text.choose_chat, callback_data = "Выбрать чат"),
    InlineKeyboardButton(text = text.go_survey_text, callback_data = "back-survey")
]

chat_buttons_menu_start = InlineKeyboardBuilder()
for i in chat_buttons_start:
    chat_buttons_menu_start.add(i).adjust(1)

chat_buttons_back = [
    InlineKeyboardButton(text = text.continue_text, callback_data = "Следующий чат"),
    InlineKeyboardButton(text = text.choose_chat, callback_data = "Выбрать чат"),
    InlineKeyboardButton(text = text.back_text, callback_data = "Назад")
]

chat_buttons_end = [
    InlineKeyboardButton(text = text.choose_chat, callback_data = "Выбрать чат"),
    InlineKeyboardButton(text = text.back_text, callback_data = "Назад")
]

chat_buttons_menu_back = InlineKeyboardBuilder()
for i in chat_buttons_back:
    chat_buttons_menu_back.add(i).adjust(1)
        
chat_buttons_menu_end = InlineKeyboardBuilder()
for i in chat_buttons_end:
    chat_buttons_menu_end.add(i).adjust(1)

chat_realize = ["Сохранить результаты", "Следующий чат", "Назад", "Выбрать чат"]

# После выбора чата
choose_chat_buttons = [
    InlineKeyboardButton(text = text.next_member, callback_data = "Следующая анкета"),
    InlineKeyboardButton(text = text.back_to_chats, callback_data = "Вернуться к выбору чатов")
]

choose_chat_buttons2 = [
    InlineKeyboardButton(text = text.buy_text, callback_data = "Оплатить"),
    InlineKeyboardButton(text = text.back_to_chats, callback_data = "Сохранить результаты2")
]

choose_chat_buttons22 = [
    InlineKeyboardButton(text = text.buy_text, callback_data = "Оплатить"),
    InlineKeyboardButton(text = text.back_to_chats, callback_data = "Скрыть")
]

choose_chat_buttons3 = [
    #InlineKeyboardButton(text = text.buy_text, callback_data = "Оплатить"),
    InlineKeyboardButton(text = text.back_to_chats, callback_data = "Вернуться к выбору чатов")
]

choose_chat_buttons4 = [
    InlineKeyboardButton(text = text.buy_text, callback_data = "Оплатить"),
    InlineKeyboardButton(text = text.go_survey_text, callback_data = "back-survey")
]

choose_chat_buttons5 = [
    InlineKeyboardButton(text = "Скрыть сообщение", callback_data = "Скрыть")
]

choose_chat_menu22 = InlineKeyboardBuilder()
for i in choose_chat_buttons22:
    choose_chat_menu22.add(i).adjust(1)

choose_chat_menu5 = InlineKeyboardBuilder()
for i in choose_chat_buttons5:
    choose_chat_menu5.add(i).adjust(1)

choose_chat_menu4 = InlineKeyboardBuilder()
for i in choose_chat_buttons4:
    choose_chat_menu4.add(i).adjust(1)

choose_chat_menu3 = InlineKeyboardBuilder()
for i in choose_chat_buttons3:
    choose_chat_menu3.add(i).adjust(1)

choose_chat_menu = InlineKeyboardBuilder()
for i in choose_chat_buttons:
    choose_chat_menu.add(i).adjust(1)

choose_chat_menu2 = InlineKeyboardBuilder()
for i in choose_chat_buttons2:
    choose_chat_menu2.add(i).adjust(1)
#РАБОТА С ГРУППАМИ
chat_join_button = InlineKeyboardButton(text=text.chat_join_button_text, callback_data='chat_join')

chat_join = InlineKeyboardBuilder()
chat_join.add(chat_join_button)

#КНОПКА ИНФОРМАЦИИ О ГРУППЕ:
info_button_answers = ["get_info"]
info_button = InlineKeyboardButton(text = text.info_button_text, callback_data = 'get_info')

info_menu = InlineKeyboardBuilder()
info_menu.add(info_button)

#Кнопки для оплаты:
def give_p2p_buttons(quickpay):
    p2p_buttons = [
        InlineKeyboardButton(text = p2p_messages.buy_button, url = quickpay.redirected_url),
        InlineKeyboardButton(text = "Проверить оплату!", callback_data = 'claim'),
        InlineKeyboardButton(text = "Вернуться к опросу", callback_data = 'back-survey')
    ]
    p2p_menu = InlineKeyboardBuilder()
    for i in p2p_buttons:
        p2p_menu.add(i).adjust(1)
    return p2p_menu