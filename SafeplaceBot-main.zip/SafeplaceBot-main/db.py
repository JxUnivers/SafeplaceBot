from sqlalchemy import create_engine, text

#ДЛЯ КНОПОК
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.types import InlineKeyboardButton


def connect_to_base():
    database_type = 'mysql'  
    user = 'u2098529_default'
    password = 'm11U0kyC5NIo7PJA'
    host = '31.31.196.3'
    port = '3306'
    database_name = 'u2098529_SafePlaceBot'
    database_uri = f'{database_type}://{user}:{password}@{host}:{port}/{database_name}'
    
    # Создание объекта Engine
    engine = create_engine(database_uri)
    connection = engine.connect()
    #print(connection) # проверка подключения
    return connection

# принимает строку запроса и возвращает результат
def fetcher(connection, query):
    result = connection.execute(text(query))
    result = result.fetchall()
    return result

# выполняет строку запроса, в которой не нужен возврат значений
def commiter(connection, query):
    connection.execute(text(query))
    connection.commit()


def insert_data_clients(connection, answers):
    def trans_2(val):
        for i,k in trans.items():
            if val in i:
                return k
        return val
    
    
    def is_new(connection, answers):
        id = answers["user_id"]
        sql_query = f'SELECT user_id FROM clients WHERE user_id = {id}'
        result = connection.execute(text(sql_query))
        rows = result.fetchall()
        if rows:
            return False
        else:
            return True
        

    items = answers.items()
    all_keys = [x[0] for x in items]
    all_values = [f'"{x[1]}"' for x in items]
    
    
    trans = {
        ('"Есть (артист)"',
        '"Есть (сонграйтер)"', 
        '"Да, работал онлайн"', 
        '"Есть (артист)"', 
        '"Есть (сонграйтер)"', 
        '"Да, работал онлайн"', 
        '"Да, работал в команде"',
        '"Да, играю"'  
        ): 'TRUE',
        
        ('"Меньше месяца"'): '1',
        ('"Несколько месяцев"'): '2',
        ('"Около года"'): '3',
        ('"Больше двух лет"'): '4',
        
         ('"Нет (артист)"',
        '"Нет (сонграйтер)"',
        '"Нет, не работал"',
        '"Нет, работал один"',
        '"Нет, не играю"'
        ): 'FALSE',
    }

    all_values = list(map(trans_2, all_values))
    
    if is_new(connection, answers):
        sql_query = f'INSERT INTO clients ({", ".join(all_keys)}) VALUES ({", ".join(all_values)})'
    else:
        new = [f'{all_keys[i]} = {all_values[i]}' for i in range(len(all_keys))]
        sql_query = f'UPDATE clients SET melody_or_text = NULL, {", ".join(new)} WHERE user_id = {answers["user_id"]}'

    connection.execute(text(sql_query))
    connection.commit()
    
# НАЧАЛО 
# РАБОТЫ
# C ГРУППОЙ
def is_in_group(connection, user_id):
    sql_query = f'SELECT group_id FROM clients WHERE user_id = "{user_id}";'
    group = fetcher(connection, sql_query)[0][0]
    if group:
        return True
    return False

def get_link(connection, group_id):
    sql_query = f'SELECT group_link FROM groups WHERE group_id = "{group_id}";'
    return fetcher(connection, sql_query)[0]
        


def is_artist(connection, user_id):
    sql_query = f'SELECT client_role FROM clients WHERE user_id = "{user_id}";'
    result = fetcher(connection, sql_query)[0][0]
    if result == "Я артист":
        return True
    return False

# Обновляет словарь answers_all данными о юзерах в группе через БД
def update_answers(connection, user_id, answers_all):
    sql_query = f'SELECT client_role, has_song_on_platform, melody_or_text, has_experience_online, has_team_experience, work_experience, play_music_instruments, time_zone, client_genre, client_name FROM clients where user_id = {user_id}'
    result = fetcher(connection, sql_query)[0]
    
    answers_list = [result[1], result[3], result[4], result[6]]
    answers_list_replace = []
    for value in answers_list:
        if value == 1:
            value = "Да"
        else:
            value = "Нет"    
        answers_list_replace.append(value)
    
    
    work_experience = result[5]
    if work_experience == 1:
        work_experience = "Меньше месяца"
    elif work_experience == 2:
        work_experience = "Несколько месяцев"
    elif work_experience == 3:
        work_experience = "Около года"
    else:
        work_experience = "Больше двух лет"
        
    
    answers = {
        'client_role': result[0],
        'has_song_on_platform': answers_list_replace[0], #число
        'melody_or_text': result[2],
        'has_experience_online': answers_list_replace[1], #число
        'has_team_experience': answers_list_replace[2], #val
        'work_experience': work_experience, #val
        'play_music_instruments' : answers_list_replace[3], #val
        'time_zone': result[7],
        'client_genre': result[8],
        'client_name': result[9]
    }
    answers_all[user_id] = answers
# Добавляет поле group_id в clients для чела, который присоединился к группе
def add_group_id(connection, user_id, group_id):
    sql_query = f'UPDATE clients SET group_id = {group_id} WHERE user_id = "{user_id}";'
    connection.execute(text(sql_query))
    connection.commit()
    
# Создает новую строку в groups при добавлении нами бота в новую группу
def create_group(connection, info):
    keys = info.keys()
    values = info.values()
    sql_query = f'INSERT INTO groups ({", ".join(keys)}) VALUES ({", ".join(values)});'
    connection.execute(text(sql_query))
    connection.commit()


# Обновляет строку группы, при присоединении чела (поле songwriters или has_artist)
def update_members_groups_add(connection, user_id, group_id):
    if is_artist(connection, user_id):
        sql_query = f'UPDATE groups SET has_artist = 1 WHERE group_id = "{group_id}";'
    else:
        sql_query = f'SELECT songwriters FROM groups WHERE group_id = "{group_id}";'
        result = fetcher(connection, sql_query)[0][0]
        songwriters_count = int(result) + 1
        sql_query = f'UPDATE groups SET songwriters = {songwriters_count} WHERE group_id = "{group_id}";'
    commiter(connection, sql_query)

# Обновляет строку группы, при выходе из группы чела (поле songwriters или has_artist)
def update_members_groups_quit(connection, user_id, group_id):
    if is_artist(connection, user_id):
        sql_query = f'UPDATE groups SET has_artist = 0 WHERE group_id = "{group_id}";'
    else:
        sql_query = f'SELECT songwriters FROM groups WHERE group_id = "{group_id}";'
        result = fetcher(connection, sql_query)[0][0]
        songwriters_count = int(result) - 1
        sql_query = f'UPDATE groups SET songwriters = {songwriters_count} WHERE group_id = "{group_id}";' 
    connection.execute(text(sql_query))
    connection.commit()

# Удаляет поле group_id в clients для чела, который вышел из группы
def delete_group_id(connection, user_id):
    sql_query = f'UPDATE clients SET group_id = 0 WHERE user_id = "{user_id}";'
    connection.execute(text(sql_query))
    connection.commit()
    
# Фильтр для поиска чатов для артиста
# def filter_chat(connection, answers):
#     genre = answers['client_genre']
 
def give_empty_chat(connection, answers, id):
    genre = answers['client_genre']
    sql_query = f'SELECT group_name FROM groups WHERE (group_status = "INACTIVE") AND group_name LIKE "%{genre}%" LIMIT 1;'
    result = fetcher(connection, sql_query)
    print("result 2: ", result)
    group_name = result[0]
    return group_name
        
    
    
# Выдаём список чатов для артиста c фильтром 
def search_chats_for_artist(connection, answers, id):
    genre = answers['client_genre']
    result = None
    if is_artist(connection, id):
        sql_query = f'SELECT group_name FROM groups WHERE (group_status = "ACTIVE" OR "TIMER") AND has_artist = 0;'
        result = fetcher(connection, sql_query)
    else:
        sql_query = f'SELECT group_name FROM groups WHERE (group_status = "ACTIVE" OR group_status = "TIMER") AND songwriters < 3;'
        result = fetcher(connection, sql_query)
        
    print("result: ", result)
    #if not result:
        #sql_query = f'SELECT group_name FROM groups WHERE group_status = "INACTIVE";'
        #result = fetcher(connection, sql_query)
        
    group_name_list = list()
    chat_buttons = list()
    for i in range(len(result)):
        if genre in result[i][0]:
            group_name = result[i][0]
            group_name_list.insert(0, group_name)
        else:  
            group_name = result[i][0]
            group_name_list.append(group_name)
            
    
    #for group_name in group_name_list:
        #chat_button = InlineKeyboardButton(text=f'{group_name}', callback_data = f'{group_name}')
        #chat_buttons.append(chat_button)
            
          
    return group_name_list
    #return chat_buttons
# Получаем список из айди чатов после фильтра    
def get_chat_id(connection, group_name_list):
    group_id_list = list()
    for i in range(len(group_name_list)):
        group_name_val = group_name_list[i]
        sql_query = f'SELECT group_id FROM groups WHERE group_name LIKE "{group_name_val}";'
        result = fetcher(connection, sql_query)
        print(result)
        group_id = result[0][0]
        group_id_list.append(group_id)
    
        
        
    print(group_id_list)
    return group_id_list
    
    
# Получаем персональное имя чата
def get_private_name(connection, chat_id_list):
    private_name_list = list()
    for i in range(len(chat_id_list)):
        chat_id_value = chat_id_list[i]
        sql_query = f'SELECT private_name FROM groups WHERE group_id = "{chat_id_value}";'
        result = fetcher(connection, sql_query)
        private_name = result[0][0]
        private_name_list.append(private_name)
    
    return private_name_list

# Выдаём ссылку по нажатой кнопке    
def find_link_for_artist(connection, chat_index):
    sql_query = f'SELECT group_link FROM groups WHERE group_name = "{chat_index}";'
    result = fetcher(connection, sql_query)[0]
    return result[0]

def send_link_for_admin(connection, group_id):
    sql_query = f'SELECT group_link FROM groups WHERE group_id = {group_id};'
    result = fetcher(connection, sql_query)[0]
    return result[0]

# Находим айди группы по выбору конпки
def find_group_id(connection, chat_index):
    sql_query = f'SELECT group_id FROM groups WHERE group_name = "{chat_index}";'
    result = fetcher(connection, sql_query)[0][0]
    return result

# Собираем информацию о людях в каждом чате
def get_info_group(connection, chat_id_list):
    group_info_list = list()
    for i in range(len(chat_id_list)):
        group_id = chat_id_list[i]
        sql_query = f'SELECT has_artist, songwriters, group_status from groups WHERE group_id = "{group_id}";'
        result = fetcher(connection, sql_query)
        has_artist = result[0][0]
        songwriters = result[0][1]
        group_status = result[0][2]
        result = result[0]
        result = list(result)
        group_info_list.append(list(result))
        
    print(group_info_list)
    return group_info_list
    
def get_members_id(connection, group_id):
    sql_query = f'SELECT user_id from clients WHERE group_id = "{group_id}";'
    user_ids = fetcher(connection, sql_query)
    return user_ids
        
              
            

    
       
    
            
# СТАТУСЫ ГРУППЫ
# Inactive - в группе 0 человек
# Active - в группе есть хотя бы 1 человек, но в ней нет одновременно артиста и хотя бы 1 сонграйтера
# Timer - в группе есть хотя бы 1 артист и сонграйтер, запущен таймер в неделю для поиска доп. сонграйтеров
# Working - группа работает над треком, таймер в месяц запущен  
def update_status(connection, group_id):
    sql_query = f'SELECT has_artist, songwriters FROM groups WHERE group_id = "{group_id}";'
    artist, songwriters = fetcher(connection, sql_query)[0]
    if artist and songwriters == 3:
        status = 'WORKING'
    elif artist and songwriters:
        status = 'TIMER'
    elif artist or songwriters:
        status = 'ACTIVE'
    else:
        status = "INACTIVE"
    sql_query = f'UPDATE groups SET group_status = "{status}" WHERE group_id = "{group_id}";'
    commiter(connection, sql_query)

def insert_chat_name(connection, chat_name, group):
    sql_query = f'UPDATE groups SET private_name = "{chat_name}" WHERE group_id = {group};'
    connection.execute(text(sql_query))
    connection.commit()
    
    
#Работа с оплатой p2p

def add_user(connection, user_id, name, role):
    try:
        sql_query = f'INSERT INTO users_p2p (user_id, name, role) VALUES ({user_id}, "{name}", "{role}");'
        connection.execute(text(sql_query))
        connection.commit()
    except Exception as e:
        sql_query = f'UPDATE users_p2p SET role = "again" WHERE user_id = {user_id};'
        connection.execute(text(sql_query))
        connection.commit()
        
        
    
def update_label(connection, label, user_id):
    sql_query = f'UPDATE users_p2p SET label = "{label}" WHERE user_id = {user_id};'
    connection.execute(text(sql_query))
    connection.commit()
    
def get_payment_status(connection, user_id):
    sql_query = f'SELECT bought, label FROM users_p2p where user_id = {user_id}'
    result = fetcher(connection, sql_query)
    return result

def update_payment_status(connection, user_id):
    sql_query = f'UPDATE users_p2p SET bought = 1 WHERE user_id = {user_id};'
    connection.execute(text(sql_query))
    connection.commit()
    
    