from aiogram import types, F, Router, Bot
from aiogram.types import Message, ContentType, ChatMemberUpdated
from aiogram.filters import Command, IS_NOT_MEMBER, IS_MEMBER, ChatMemberUpdatedFilter
from aiogram import enums
from filters import ChatTypeFilter
from datetime import datetime, timedelta
import asyncio
import text

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder
from admin import admin_id
from aiogram.types import FSInputFile

from yoomoney import Quickpay, Client
from config_db import hostname, username, pwd, db_name, port_id


import db
import kb
import string
import random
import p2p_messages
import config_p2p



router = Router()
answers_all = {}
bot = Bot(token='6922951398:AAEVS4gtEKTkTjNaqwQh8o2iDI0eKRvxVnk')
#key = {"id": 0}
key = {}
admin_call = 0
chat_final = {}


@router.message(ChatTypeFilter(chat_type = ['private']), Command("start"))
async def start_handler(msg: Message):
    await msg.answer(text.greet.format(name=msg.from_user.full_name), reply_markup=kb.menu_start.as_markup())
    global answers_all
    answers = {}
    answers["user_id"] = msg.from_user.id
    answers["client_name"] = '@' + msg.from_user.username
    id = msg.from_user.id
    answers_all[id] = answers

@router.callback_query(F.data == 'start_survey')
async def first_question(callback: types.CallbackQuery):
    await callback.message.answer(text.first_question, reply_markup=kb.first_question_menu.as_markup())
    await callback.answer()
    
@router.callback_query(F.data == 'repeat-survey')
async def repeat_survey(callback: types.CallbackQuery):
    await callback.message.answer(text.first_question, reply_markup=kb.first_question_menu.as_markup())
    await callback.answer()


@router.callback_query(F.data == 'Я артист')
async def second_question(callback: types.CallbackQuery):
    #await callback.message.answer(text.third_question_artist, reply_markup=kb.third_question_menu_artist.as_markup())
    await callback.message.answer(text.second_question, reply_markup=kb.second_question_menu.as_markup())
    await callback.answer()
    global answers_all
    answers = {}
    answers["client_role"] = callback.data
    id = callback.from_user.id
    answers_all[id] |= answers

@router.callback_query(F.data == 'Я сонграйтер')
async def second_question(callback: types.CallbackQuery):
    #await callback.message.answer(text.third_question_songwriter, reply_markup=kb.third_question_menu_songwriter.as_markup())
    await callback.message.answer(text.second_question, reply_markup=kb.second_question_menu.as_markup())
    await callback.answer()
    global answers_all
    answers = {}
    answers["client_role"] = callback.data
    id = callback.from_user.id
    answers_all[id] |= answers
    
@router.callback_query(F.data.in_(kb.third_answers_artist))
async def sixth_question_artist(callback: types.CallbackQuery):
    await callback.message.answer(text.sixth_question_artist, reply_markup=kb.sixth_question_menu.as_markup())
    await callback.answer()
    global answers_all
    answers = {}
    answers["has_song_on_platform"] = callback.data
    id = callback.from_user.id
    answers_all[id] |= answers


@router.callback_query(F.data.in_(kb.third_answers_songwriter))
async def extra_question_songwriter(callback: types.CallbackQuery):
    await callback.message.answer(text.extra_question_songwriter, reply_markup=kb.extra_question_menu.as_markup())
    await callback.answer()
    global answers_all
    answers = {}
    answers["has_song_on_platform"] = callback.data
    id = callback.from_user.id
    answers_all[id] |= answers

@router.callback_query(F.data.in_(kb.extra_answers_songwriter))
async def sixth_question_songwriter(callback: types.CallbackQuery):
    await callback.message.answer(text.sixth_question_songwriter, reply_markup=kb.sixth_question_menu.as_markup())
    await callback.answer()
    global answers_all
    answers = {}
    answers["melody_or_text"] = callback.data
    id = callback.from_user.id
    answers_all[id] |= answers



@router.callback_query(F.data.in_(kb.sixth_answers))
async def second_question(callback: types.CallbackQuery):
    await callback.message.answer(text.second_question, reply_markup=kb.second_question_menu.as_markup())
    await callback.answer()
    global answers_all
    answers = {}
    answers["work_experience"] = callback.data
    id = callback.from_user.id
    answers_all[id] |= answers

@router.callback_query(F.data.in_(kb.genres))
async def fourth_question_artist(callback: types.CallbackQuery):
    #await callback.message.answer(text.fourth_question, reply_markup=kb.fourth_question_menu.as_markup())
    await callback.message.answer(text.eighth_question, reply_markup=kb.eighth_question_menu.as_markup())
    await callback.answer()
    global answers_all
    answers = {}
    answers["client_genre"] = callback.data
    id = callback.from_user.id
    answers_all[id] |= answers

            
@router.callback_query(F.data.in_(kb.fourth_answers))
async def fifth_question_artist(callback: types.CallbackQuery):
    await callback.message.answer(text.fifth_question, reply_markup=kb.fifth_question_menu.as_markup())
    await callback.answer()
    global answers_all
    answers = {}
    answers["has_experience_online"] = callback.data
    id = callback.from_user.id
    answers_all[id] |= answers

    
@router.callback_query(F.data.in_(kb.fifth_answers))
async def seventh_question_artist(callback: types.CallbackQuery):
    await callback.message.answer(text.seventh_question, reply_markup=kb.seventh_question_menu.as_markup())
    await callback.answer()
    global answers_all
    answers = {}
    answers["has_team_experience"] = callback.data
    id = callback.from_user.id
    answers_all[id] |= answers


            
@router.callback_query(F.data.in_(kb.seventh_answers))
async def eighth_question_artist(callback: types.CallbackQuery):
    await callback.message.answer(text.eighth_question, reply_markup=kb.eighth_question_menu.as_markup())
    await callback.answer()
    global answers_all
    answers = {}
    answers["play_music_instruments"] = callback.data
    id = callback.from_user.id
    answers_all[id] |= answers
                
@router.callback_query(F.data.in_(kb.eighth_answers))
async def end_phrase(callback: types.CallbackQuery):
    global answers_all
    answers = {}
    answers["time_zone"] = callback.data
    id = callback.from_user.id
    answers_all[id] |= answers
    await callback.message.answer(text.parse_answers(answers_all[id]))
    await callback.message.answer(text.end_phrase, reply_markup = kb.end_menu.as_markup())
    await callback.answer()
        
@router.callback_query(F.data == "Сохранить результаты")
async def save_data(callback: types.CallbackQuery):
    id = callback.from_user.id
    global key
    global chat_final
    key_value = 0
    key[id] = key_value
    flag = 0
    value = callback.data
    #await callback.message.answer(text.end_text)
    answers = {}
    answers_all[id] |= answers
    db.insert_data_clients(db.connect_to_base(), answers_all[id])
    chat_message = db.search_chats_for_artist(db.connect_to_base(), answers_all[id], id)
    if chat_message == []:
        flag = 1
        chat_message = None
        chat_message = db.give_empty_chat(db.connect_to_base(), answers_all[id], id)
    chat_id_list = db.get_chat_id(db.connect_to_base(), chat_message)
    private_name_list = db.get_private_name(db.connect_to_base(), chat_id_list)
    info_group_list = db.get_info_group(db.connect_to_base(), chat_id_list)
    text_photo = f"<b>Ниже будут представлены чаты для выбора.</b>\n\nВАЖНО:\nЧат, в который вы хотите присоединиться, должен являться последним сообщением от бота."
    await callback.message.answer_photo(FSInputFile(path = 'safeplace shuff.jpg'), caption = text_photo)
    await callback.answer()
    #await callback.message.answer( ,text = "Ниже будут представлены чаты для выбора.\n\nВАЖНО:\nЧат, в который вы хотите присоединиться, должен являться последним сообщением от бота.")
    if flag == 1:
        await callback.message.answer(text.send_chats(chat_message, info_group_list, key[id], private_name_list))
        chat_final[id] = chat_message[key[id]]
        await callback.message.answer(text.empty_chat, reply_markup = kb.choose_chat_menu4.as_markup())
        await callback.answer()
    else:        
        await callback.message.answer(text.send_chats(chat_message, info_group_list, key[id], private_name_list), reply_markup = kb.chat_buttons_menu_start.as_markup())
        await callback.answer()

    
@router.callback_query(F.data == "Следующий чат")
async def next_chat(callback: types.CallbackQuery):
    await callback.message.delete() 
    id = callback.from_user.id
    global key
    key_value = key[id] + 1
    key[id] = key_value
    chat_message = db.search_chats_for_artist(db.connect_to_base(), answers_all[id], id)
    #rint(chat_message)
    #if chat_message == []:
        #chat_message = None
        #chat_message = db.give_empty_chat(db.connect_to_base(), answers_all[id], id)
    chat_id_list = db.get_chat_id(db.connect_to_base(), chat_message)
    private_name_list = db.get_private_name(db.connect_to_base(), chat_id_list)
    info_group_list = db.get_info_group(db.connect_to_base(), chat_id_list)
    try:
        await callback.message.answer(text.send_chats(chat_message, info_group_list, key[id], private_name_list), reply_markup = kb.chat_buttons_menu_back.as_markup())
        await callback.answer()
    #if not text.send_chats(chat_message, info_group_list, key[id] + 1, private_name_list):
    except IndexError:
        key_value = key[id] - 1
        key[id] = key_value
        await callback.message.answer(text.send_chats(chat_message, info_group_list, key[id], private_name_list), reply_markup = kb.chat_buttons_menu_end.as_markup())
        await callback.message.answer(text.end_chat_text, reply_markup = kb.choose_chat_menu5.as_markup())
        await callback.answer()

@router.callback_query(F.data == "Создать свой чат")
async def create_empty_chat(callback: types.CallbackQuery):
    id = callback.from_user.id
    global key
    global answers_all
    key_value = 0
    key[id] = key_value
    chat_message = []
    answers = {}
    answers_all[id] |= answers
    chat_message = db.give_empty_chat(db.connect_to_base(), answers_all[id], id)
    chat_id_list = db.get_chat_id(db.connect_to_base(), chat_message)
    private_name_list = db.get_private_name(db.connect_to_base(), chat_id_list)
    info_group_list = db.get_info_group(db.connect_to_base(), chat_id_list)
    await callback.message.answer(text.send_chats(chat_message, info_group_list, key[id], private_name_list))
    await callback.message.answer(text.empty_chat, reply_markup = kb.choose_chat_menu4.as_markup())
    await callback.answer()
    
    
    
@router.callback_query(F.data == "Выбрать чат")
async def choose_chat(callback: types.CallbackQuery):
    id = callback.from_user.id
    await callback.message.delete()
    global key
    global chat_final
    key_value = key[id]
    chat_message = db.search_chats_for_artist(db.connect_to_base(), answers_all[id], id)
    chat_final[id] = chat_message[key[id]]
    chat_id_list = db.get_chat_id(db.connect_to_base(), chat_message)
    info_group_list = db.get_info_group(db.connect_to_base(), chat_id_list)
    chat_id = chat_id_list[key_value]
    private_name_list = db.get_private_name(db.connect_to_base(), chat_id_list)
    all_members_id = db.get_members_id(db.connect_to_base(), chat_id)
    all_members_id = [i[0] for i in all_members_id]
    text0 = ''
    text2 = list()
    final_text = ''
    if len(all_members_id) != 0:
        #await callback.message.answer(text.send_choosen_chat(chat_message, info_group_list, key[id], private_name_list))
        for member_id in all_members_id:
            db.update_answers(db.connect_to_base(), member_id, answers_all)
            text2.append(text.parse_answers_chats(answers_all[member_id], answers_all[member_id]['client_role'], answers_all[member_id]['client_name']))
            
        for count in text2:
            count = 0
            try:
                final_text = f'{text2[count]}\n\n{text2[count + 1]}'
            except IndexError:
                break
            
             
        #await callback.message.answer(text = f'{text.parse_answers_chats(answers_all[member_id], answers_all[member_id]['client_role'], answers_all[member_id]['client_name'])}\n\n{text.end_of_survey}', reply_markup = kb.choose_chat_menu2.as_markup())
        await callback.message.answer(text = f'{final_text}\n\n{text.end_of_survey}', reply_markup = kb.choose_chat_menu2.as_markup())
        await callback.answer()
        
    else:
        #await callback.message.delete()
        #await callback.message.answer(text.send_choosen_chat(chat_message, info_group_list, key[id], private_name_list), reply_markup = kb.chat_buttons_menu_start.as_markup())
        await callback.message.answer(text.empty_chat2, reply_markup = kb.choose_chat_menu22.as_markup())
        await callback.answer()

@router.callback_query(F.data == "Сохранить результаты2")
async def back_to_chats(callback: types.CallbackQuery):
    await callback.message.delete()
    id = callback.from_user.id
    global key
    answers = {}
    answers_all[id] |= answers
    chat_message = db.search_chats_for_artist(db.connect_to_base(), answers_all[id], id)
    chat_id_list = db.get_chat_id(db.connect_to_base(), chat_message)
    private_name_list = db.get_private_name(db.connect_to_base(), chat_id_list)
    info_group_list = db.get_info_group(db.connect_to_base(), chat_id_list)
    await callback.message.answer(text.send_chats(chat_message, info_group_list, key[id], private_name_list), reply_markup = kb.chat_buttons_menu_start.as_markup())
    await callback.answer()
    
@router.callback_query(F.data == "Вернуться к выбору чатов")
async def go_back_chats(callback: types.CallbackQuery):
    await callback.message.delete()
       
@router.callback_query(F.data == "Назад")
async def go_back_to_chat(callback: types.CallbackQuery):
    await callback.message.delete()
    id = callback.from_user.id
    global key
    key_value = key[id] - 1
    key[id] = key_value
    chat_message = db.search_chats_for_artist(db.connect_to_base(), answers_all[id], id)
    chat_id_list = db.get_chat_id(db.connect_to_base(), chat_message)
    private_name_list = db.get_private_name(db.connect_to_base(), chat_id_list)
    info_group_list = db.get_info_group(db.connect_to_base(), chat_id_list)
    if key_value == 0:
        await callback.message.answer(text.send_chats(chat_message, info_group_list, key[id], private_name_list), reply_markup = kb.chat_buttons_menu_start.as_markup())
        await callback.answer()
    else:
        await callback.message.answer(text.send_chats(chat_message, info_group_list, key[id], private_name_list), reply_markup = kb.chat_buttons_menu_back.as_markup())
        await callback.answer()
    

    
@router.callback_query(F.data == "Скрыть")
async def delete_message(callback: types.CallbackQuery):
    await callback.message.delete()    
    
@router.callback_query(F.data == "back-survey")
async def back_to_survey(callback: types.CallbackQuery):
    await callback.message.delete()
    global answers_all
    answers = {}
    id = callback.from_user.id
    answers_all[id] |= answers
    await callback.message.answer(text.parse_answers(answers_all[id]))
    await callback.message.answer(text.end_phrase, reply_markup = kb.end_menu.as_markup())
    await callback.answer()

    #chat_buttons = db.search_chats_for_artist(db.connect_to_base(), answers_all[id], id)
    #chat_menu = InlineKeyboardBuilder()
    #for i in chat_buttons:
        #chat_menu.add(i).adjust(1)
     #   kb.chat_answers.append(i.text)
    #await callback.message.answer(text.chat_list, reply_markup = chat_menu.as_markup())
    #await callback.answer()



@router.callback_query(F.data.in_(kb.chat_answers))
async def give_link(callback: types.CallbackQuery):
    chat_index = callback.data
    id = callback.from_user.id
    answers_all[id]["chat_index"] = chat_index
    has_artist, songwriters, group_status = db.get_info_group(db.connect_to_base(), chat_index)
    
    await callback.message.answer(
        f'''Добро пожаловать в группу {chat_index}
            На данный момент статус группы - {group_status}
            Артист: {has_artist}
            Сонграйтеров: {songwriters}''', reply_markup = kb.info_menu.as_markup())
    await callback.answer()
    
@router.callback_query(F.data.in_(kb.info_button_answers))
async def give_full_info(callback: types.CallbackQuery):
    id = callback.from_user.id
    chat_index = answers_all[id]["chat_index"]
    group_id = db.find_group_id(db.connect_to_base(), chat_index)
    all_members_id = db.get_members_id(db.connect_to_base(), group_id)
    all_members_id = [i[0] for i in all_members_id]
    has_artist, songwriters, group_status = db.get_info_group(db.connect_to_base(), chat_index)
    for member_id in all_members_id:
        db.update_answers(db.connect_to_base(), member_id, answers_all)
        await callback.message.answer(text.parse_answers_chats(answers_all[member_id], answers_all[member_id]['client_role']), answers_all[member_id]['client_name'])
    link = db.find_link_for_artist(db.connect_to_base(), chat_index)
    await callback.message.answer(f'Ваша ссылка: "{link}"')
    await callback.answer()
        
    
@router.callback_query(F.data == "Оплатить")
async def p2p_payment(callback: types.CallbackQuery):
    id = callback.from_user.id
    global key
    global chat_final
    key_value = key[id]
    chat_name = chat_final[id]
    group_link = db.find_link_for_artist(db.connect_to_base(), chat_name)
    user_id = callback.from_user.id
    name = '@' + callback.from_user.username
    db.add_user(db.connect_to_base(), user_id, name, "user")
    letters_and_digits = string.ascii_lowercase + string.digits
    random_string = ''.join(random.sample(letters_and_digits, 10))
    quickpay = Quickpay(
        receiver='4100118556001873',
        quickpay_form='shop',
        targets='SafePlace',
        paymentType='SB',
        sum=2,
        label=random_string,
    )
    
    db.update_label(db.connect_to_base(), random_string, user_id)
    await callback.message.answer(text = f'Вы выбрали {chat_name} для оплаты!\n\nСумма платежа: 1500 RUB', reply_markup = kb.give_p2p_buttons(quickpay).as_markup())
    await callback.message.answer(text = p2p_messages.MESSAGES['buy'])

@router.callback_query(F.data == 'claim')
async def check_payment(callback: types.CallbackQuery):
    id = callback.from_user.id
    user_id = callback.from_user.id
    global chat_final
    chat_name = chat_final[id]
    group_link = db.find_link_for_artist(db.connect_to_base(), chat_name)
    data = db.get_payment_status(db.connect_to_base(), user_id)
    bought = data[0][0]
    label = data[0][1]
    chat_id = chat_final[id]
    group_link = db.find_link_for_artist(db.connect_to_base(), chat_id)
    if bought == 0:
        client = Client(config_p2p.Config.token_p2p)
        history = client.operation_history(label=label)
        try:
            operation = history.operations[-1]
            if operation.status == 'success':
                db.update_payment_status(db.connect_to_base(), user_id)
                await bot.send_message(callback.message.chat.id, p2p_messages.MESSAGES['successful_payment'])
                await callback.message.answer(text = f'{group_link}')
        except Exception as e:
            await bot.send_message(callback.message.chat.id, p2p_messages.MESSAGES['wait_message'])
    else:
        await bot.send_message(callback.message.chat.id, p2p_messages.MESSAGES['successful_payment'])
        await callback.message.answer(text = f'{group_link}')
        


# НАЧАЛО 
# РАБОТЫ
# С ГРУППАМИ
    
@router.message(ChatTypeFilter(chat_type = ["group", "supergroup"]), Command('send_data'))
async def insert_group_data_db(msg: Message):
        group_id = msg.chat.id
        group_name = msg.chat.title
        group_link = await bot.create_chat_invite_link(chat_id=group_id)
        info = {
                'group_id': f'"{group_id}"',
                'group_name': f'"{group_name}"',
                'group_link': f"'{group_link.invite_link}'",
                'has_artist': 'FALSE',
                'songwriters': '0',
                'group_status': "'INACTIVE'",
            }
        try:
            db.create_group(db.connect_to_base(), info)
            await msg.answer('Данные успешно отправлены')
        except:
            await msg.answer('Ошибка(')

@router.message(ChatTypeFilter(chat_type = ["group", "supergroup"]), Command('admin'))
async def invite_admin(msg: Message):
        global admin_call
        admin_call += 1 
        group_id = msg.chat.id
        group_link = db.send_link_for_admin(db.connect_to_base(), group_id)
        await bot.send_message(chat_id = group_id, text = "Запрос принят! В ближайшее время с вами свяжется админ.")
        await bot.send_message(chat_id = admin_id, text = f'Вызов в группу. Заявка #{admin_call}.\n{group_link}')
          
@router.chat_join_request(ChatTypeFilter(chat_type = ['group', 'supergroup']))
async def make_join(update: types.ChatJoinRequest):
    id = update.from_user.id
    group_id = update.chat.id
    # if db.is_in_group(db.connect_to_base(), id):
    #     await bot.send_message(chat_id = update.from_user.id, text = "Ошибка! Вы уже в группе!")
    #     return
    await update.approve()
    db.add_group_id(db.connect_to_base(), id, group_id)
    message = await bot.send_message(chat_id = group_id, text = "Для вызова доступных функций используйте команду: /help")
    await bot.unpin_chat_message(chat_id = group_id, text = "Для вызова доступных функций используйте команду: /help")
    await bot.pin_chat_message(chat_id = group_id, message_id = message.message_id)
    await bot.send_message(chat_id = update.from_user.id, text = "Вы были успешно добавлены!")
    db.update_members_groups_add(db.connect_to_base(), id, group_id)
    db.update_status(db.connect_to_base(), group_id)
 
@router.message(ChatTypeFilter(chat_type = ["group", "supergroup"]), Command('help'))
async def interact_with_bot(msg: Message):
    await msg.answer(f'''
    Ниже представлены все доступные команды:
    1) Сменить имя чата - /change_name + ИМЯ
    2) Связь с администрацией - /admin''')

    
@router.message(ChatTypeFilter(chat_type = ["group", "supergroup"]), Command('change_name'))
async def change_chat_name(msg: Message): 
    group = msg.chat.id 
    chat_name = msg.text.split(" ", 1)[1]
    await bot.set_chat_title(msg.chat.id, title = f'{chat_name}')
    db.insert_chat_name(db.connect_to_base(), chat_name, group)
    
    

        
@router.chat_member(ChatTypeFilter(chat_type = ["group", "supergroup"]), ChatMemberUpdatedFilter(IS_MEMBER >> IS_NOT_MEMBER))
async def delete_chat_info(update: types.ChatMemberUpdated):
    id = update.from_user.id
    group_id = update.chat.id
    db.delete_group_id(db.connect_to_base(), id)
    db.update_members_groups_quit(db.connect_to_base(), id, group_id)
    db.update_status(db.connect_to_base(), group_id)
    await bot.send_message(chat_id = update.from_user.id, text = "Вы покинули группу! Ждём вас снова :)")
